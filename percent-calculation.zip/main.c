#include <stdio.h>

int
main ()
{
  float x1 = 30;				//maths marks
  float x2 = 32;				//physics marks
  float x3 = 25;				//chem marks
  float x4 = 39;				//english marks

  float percent = (x1 + x2 + x3 + x4) / 1.6;
  printf ("the percent is : %f", percent);
  return 0;
}
