#include <stdio.h>

int main()
{
   int x;
   printf("enter first number : ");
   scanf("%d",&x);
   int y;
   printf("enter second number : ");
   scanf("%d",&y);
   int sum;
   sum = x + y;
   printf("the sum is : %d",sum);
    return 0;
}
