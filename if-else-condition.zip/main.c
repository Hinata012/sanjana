#include <stdio.h>

int main()
{
   int cp,sp,profit,loss;
   printf("enter the cost price : ");
   scanf("%d",&cp);
   printf("enter the selling price : ");
   scanf("%d",&sp);
   if(cp<sp){
   printf("profit\n");
   profit = sp-cp;
   printf("the profit of rupees : %d",profit);
   }
   else{
       printf("loss\n");
       loss = cp-sp;
       printf("the loss incurred is : %d",loss);
   }
   
   
    return 0;
}
