#include <stdio.h>

int main()
{
    int fahrenheit,centigrade;
    printf("enter the temperature in fahrenheit : ");
    scanf("%d",&fahrenheit);
    centigrade = (fahrenheit-32)*5/9;
    printf("the temperature is centigrade is : %d",centigrade);
    
    
    

    return 0;
}
